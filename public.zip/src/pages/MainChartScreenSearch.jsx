import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import Sidebar from "../partials/Sidebar.jsx";
import Header from "../partials/Header.jsx";
import HighchartsChart from "../components/HighchartsChart.jsx";
import { useAuth } from "../context/AuthContext.jsx";

// const API_POSTFIX = "/models/lg_hsurvey_family";
// const API_POSTFIX = "/models/lg_hsurvey_land_details";
// const API_POSTFIX = "/models/lg_hsurvey_building_details";
// const API_POSTFIX = "/models/lg_hsurvey_income_source";
// const API_POSTFIX = "/models/lg_hsurvey_expense_source"; //no data visible
// const API_POSTFIX = "/models/lg_hsurvey_saving_source";
const API_POSTFIX = "/models/lg_hsurvey_loan_source";
// const API_POSTFIX = "/models/lg_hsurvey_service_details"; //no data visible
// const API_POSTFIX = "/models/lg_hsurvey_ag_prod";
// const API_POSTFIX = "/models/lg_hsurvey_livestoke_prod"; //no data
// const API_POSTFIX = "/models/lg_hsurvey_school_time";
// const API_POSTFIX = "/models/lg_hsurvey_disaster_details";
// const API_POSTFIX = "/models/lg_hsurvey_workdivision";

const WARD_OPTIONS = [
  { value: "0", label: "वडा नं" },
  ...Array.from({ length: 12 }, (_, i) => ({
    value: String(i + 1),
    label: String(i + 1),
  })),
];

// Utility to fetch all pages and cache in localStorage
async function fetchAllPages({
  axiosInstance,
  postfix,
  filterKey,
  filterValue,
}) {
  const pageSize = 100;
  let skip = 0;
  let allRecords = [];
  let total = null;
  let pageCount = 0;
  let localKey = `${postfix}_ward_${filterValue}`;

  // Check localStorage first
  const cached = localStorage.getItem(localKey);
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed)) return parsed;
    } catch (e) {}
  }

  while (true) {
    const url = `${postfix}?$filter=${filterKey} eq '${filterValue}'&$top=${pageSize}&$skip=${skip}`;
    const res = await axiosInstance.get(url, { headers: { id: 0 } });
    const records = res.data.records || [];
    if (total === null) {
      total = res.data["row-count"] || null;
      pageCount = res.data["page-count"] || null;
    }
    allRecords = allRecords.concat(records);
    if (records.length < pageSize) break;
    skip += pageSize;
    // Defensive: break if we exceed a reasonable number of pages
    if (pageCount && skip / pageSize >= pageCount) break;
    if (total && allRecords.length >= total) break;
  }
  // Store in localStorage
  localStorage.setItem(localKey, JSON.stringify(allRecords));
  return allRecords;
}

export default function HouseholdWardSearch() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { path: param } = useParams();
  const { axiosInstance, authLoading, authError } = useAuth();
  const [ward, setWard] = useState("2");
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState({ population: 0, female: 0, male: 0 });
  const [tableData, setTableData] = useState([]);

  // Chart data
  const chartCategories = tableData.map((d) => d.label);
  const chartValues = tableData.map((d) => d.value);

  const pieOptions = {
    chart: { type: "pie" },
    title: { text: param },
    series: [
      {
        // name: "घर संख्या",
        name: "जनसंख्या",
        data: tableData.map((d) => ({ name: d.label, y: d.value })),
      },
    ],
  };

  const barOptions = {
    chart: { type: "column" },
    title: { text: param },
    xAxis: { categories: chartCategories },
    // yAxis: { title: { text: "घर संख्या" } },
    yAxis: { title: { text: "जनसंख्या" } },
    series: [
      {
        // name: "घर संख्या",
        name: "जनसंख्या",
        data: chartValues,
      },
    ],
  };

  // Handle ward selection from header
  const handleWardSelect = (selectedWard) => {
    setWard(selectedWard);
  };

  // Auto-search on param/ward/axiosInstance change
  useEffect(() => {
    async function autoSearch() {
      if (!param || !ward || !axiosInstance) return;
      setLoading(true);
      try {
        const records = await fetchAllPages({
          axiosInstance,
          postfix: API_POSTFIX,
          filterKey: "ward_no",
          filterValue: ward,
        });
        // Group by param
        const group = {};
        records.forEach((rec) => {
          let val = rec[param];
          if (val === null || val === undefined || val === "") val = "अन्य";
          group[val] = (group[val] || 0) + 1;
        });
        const data = Object.entries(group).map(([label, value]) => ({
          label,
          value,
        }));
        setTableData(data);
        // Optionally update summary (dummy for now)
        setSummary({
          population: records.length,
          female: 697,
          male: 748,
        });
      } catch (e) {
        setTableData([]);
      } finally {
        setLoading(false);
      }
    }
    autoSearch();
  }, [param, ward, axiosInstance]);

  if (authLoading) {
    return (
      <div className="p-8 text-gray-700">
        Loading website content (fetching API token)...
      </div>
    );
  }
  if (authError) {
    return (
      <div className="p-8 text-red-500">
        Error initializing API: {authError}
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
      <div className="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
        <Header
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
          onSelectWard={handleWardSelect}
        />
        <main className="flex-grow">
          <div className="container mx-auto p-4">
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <SummaryCard
                icon="fas fa-users"
                value={summary.population}
                label="जम्मा जनसंख्या"
              />
              <SummaryCard
                icon="fas fa-user-alt"
                value={summary.female}
                label="महिला"
              />
              <SummaryCard
                icon="fas fa-user-alt"
                value={summary.male}
                label="पुरुष"
              />
            </div>

            {/* Charts */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <HighchartsChart options={pieOptions} title="" height="350px" />
              <HighchartsChart options={barOptions} title="" height="350px" />
            </div>

            {/* Table */}
            <div className="card bg-white rounded shadow">
              <div className="card-body p-4">
                <div className="overflow-x-auto">
                  <table className="table table-bordered table-sm w-full border border-gray-300 text-sm hover:table-hover">
                    <thead className="bg-blue-600">
                      <tr>
                        <th className="text-center text-white font-semibold">
                          {param}
                        </th>
                        <th className="text-center text-white font-semibold">
                          {/* घर संख्या */}
                          जनसंख्या
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {tableData.map((row, idx) => (
                        <tr
                          key={idx}
                          className={
                            idx % 2 === 0
                              ? "bg-white hover:bg-blue-50"
                              : "bg-gray-50 hover:bg-blue-50"
                          }
                        >
                          <td className="text-center align-middle py-1 px-2">
                            {row.label}
                          </td>
                          <td className="text-center align-middle py-1 px-2 font-medium">
                            {row.value}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-gray-200">
                      <tr>
                        <td className="text-center font-bold py-1 px-2">
                          जम्मा
                        </td>
                        <td className="text-center font-bold py-1 px-2">
                          {tableData.reduce((sum, r) => sum + r.value, 0)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}

function SummaryCard({ icon, value, label }) {
  return (
    <div className="bg-gray-100 rounded-lg shadow p-4 flex items-center">
      <div className="flex-shrink-0 mr-4">
        <div className="w-16 h-16 flex items-center justify-center rounded-full bg-blue-100">
          <i className={`${icon} text-3xl text-blue-600`} />
        </div>
      </div>
      <div>
        <div className="text-2xl font-bold text-gray-800">{value}</div>
        <div className="text-gray-600">{label}</div>
      </div>
    </div>
  );
}

// import React, { useState, useEffect, useRef } from "react";
// import { useParams } from "react-router-dom";
// import ReportSidebar from "../partials/Sidebar.jsx"; // Renamed from Sidebar to ReportSidebar for clarity
// import Header from "../partials/Header.jsx";
// import HighchartsChart from "../components/HighchartsChart.jsx";
// import { useAuth } from "../context/AuthContext.jsx";
// import { fetchParameterOptions } from "../components/chartSidebar"; // Import the utility function

// const API_POSTFIX_HSURVEY = "/models/lg_hsurvey_family"; // For Household Reports
// const API_POSTFIX_OSURVEY = "/models/lg_osurvey"; // For Institutional Reports

// const WARD_OPTIONS = [
//   { value: "0", label: "वडा नं" },
//   ...Array.from({ length: 12 }, (_, i) => ({
//     value: String(i + 1),
//     label: String(i + 1),
//   })),
// ];

// // Add CSS for spinning animation (same as in MyDataComponent.jsx)
// const spinAnimation = `
//   @keyframes spin {
//     0% { transform: rotate(0deg); }
//     100% { transform: rotate(360deg); }
//   }
// `;

// // Utility to fetch all pages and cache in localStorage
// async function fetchAllPages({
//   axiosInstance,
//   postfix, // This will be dynamic now
//   filterKey,
//   filterValue,
// }) {
//   const pageSize = 100;
//   let skip = 0;
//   let allRecords = [];
//   let total = null;
//   let pageCount = 0;
//   // Ensure localKey differentiates between household and institutional data for the same ward
//   let localKey = `report_${postfix.replace(/\//g, "_")}_ward_${filterValue}`; // e.g., report__models_lg_hsurvey_ward_2

//   // Check localStorage first
//   const cached = localStorage.getItem(localKey);
//   if (cached) {
//     try {
//       const parsed = JSON.parse(cached);
//       if (Array.isArray(parsed)) return parsed;
//     } catch (e) {
//       // Fallback to fetch if parsing fails
//       console.warn("Failed to parse cached data, fetching again.", e);
//       localStorage.removeItem(localKey); // Clear bad cache
//     }
//   }

//   while (true) {
//     const url = `${postfix}?$filter=${filterKey} eq '${filterValue}'&$top=${pageSize}&$skip=${skip}`;
//     const res = await axiosInstance.get(url, { headers: { id: 0 } });
//     const records = res.data.records || [];
//     if (total === null) {
//       total = res.data["row-count"] || null;
//       pageCount = res.data["page-count"] || null;
//     }
//     allRecords = allRecords.concat(records);
//     if (records.length < pageSize) break;
//     skip += pageSize;
//     // Defensive: break if we exceed a reasonable number of pages
//     if (pageCount && skip / pageSize >= pageCount) break;
//     if (total && allRecords.length >= total) break;
//   }
//   // Store in localStorage
//   localStorage.setItem(localKey, JSON.stringify(allRecords));
//   return allRecords;
// }

// export default function HouseholdWardSearch() {
//   const [sidebarOpen, setSidebarOpen] = useState(false);
//   const { path: param } = useParams(); // 'path' parameter from route, e.g., 'Name', 'Caste'
//   const { axiosInstance, authLoading, authError } = useAuth();
//   const [ward, setWard] = useState("2");
//   const [loading, setLoading] = useState(false);
//   const [summary, setSummary] = useState({ population: 0, female: 0, male: 0 });
//   const [tableData, setTableData] = useState([]);
//   const [dataError, setDataError] = useState(null);

//   // New states to store fetched column options
//   const [householdColumns, setHouseholdColumns] = useState([]);
//   const [institutionalColumns, setInstitutionalColumns] = useState([]);
//   // State to hold the API postfix currently being used for data fetching
//   const [currentApiPostfix, setCurrentApiPostfix] = useState(null);

//   // Inject CSS animation for the spinner once
//   useEffect(() => {
//     const style = document.createElement("style");
//     style.textContent = spinAnimation;
//     document.head.appendChild(style);

//     return () => {
//       document.head.removeChild(style);
//     };
//   }, []);

//   // Fetch both household and institutional column options
//   useEffect(() => {
//     async function getColumnOptions() {
//       if (!axiosInstance) return;

//       try {
//         const householdOpts = await fetchParameterOptions({
//           axiosInstance,
//           apiPostfix: API_POSTFIX_HSURVEY,
//         });
//         setHouseholdColumns(householdOpts.options);

//         const institutionalOpts = await fetchParameterOptions({
//           axiosInstance,
//           apiPostfix: API_POSTFIX_OSURVEY,
//         });
//         setInstitutionalColumns(institutionalOpts.options);
//       } catch (e) {
//         console.error("Error fetching column options:", e);
//         // Handle error, e.g., set an error state or default to empty
//         setHouseholdColumns([]);
//         setInstitutionalColumns([]);
//       }
//     }
//     getColumnOptions();
//   }, [axiosInstance]);

//   // Determine the correct API_POSTFIX based on the 'param'
//   useEffect(() => {
//     if (
//       param &&
//       (householdColumns.length > 0 || institutionalColumns.length > 0)
//     ) {
//       if (householdColumns.some((col) => col.value === param)) {
//         setCurrentApiPostfix(API_POSTFIX_HSURVEY);
//       } else if (institutionalColumns.some((col) => col.value === param)) {
//         setCurrentApiPostfix(API_POSTFIX_OSURVEY);
//       } else {
//         // If param does not match any known column, default or show error
//         setCurrentApiPostfix(null);
//         setDataError(
//           `Invalid parameter: '${param}'. Please select a valid report column.`
//         );
//         setTableData([]);
//         setSummary({ population: 0, female: 0, male: 0 });
//       }
//     } else {
//       setCurrentApiPostfix(null); // Clear if no param or columns not loaded yet
//     }
//   }, [param, householdColumns, institutionalColumns]);

//   // Auto-search on param/ward/axiosInstance/currentApiPostfix change
//   useEffect(() => {
//     async function autoSearch() {
//       if (authLoading || authError || !axiosInstance || !currentApiPostfix) {
//         // Wait for auth, and currentApiPostfix to be determined
//         if (!currentApiPostfix && param) {
//           // Only show loading if we are actively trying to determine postfix
//           setLoading(true); // Still loading while determining postfix
//         } else {
//           setLoading(false);
//         }
//         return;
//       }

//       setLoading(true);
//       setDataError(null); // Clear previous data errors
//       setTableData([]); // Clear previous data
//       setSummary({ population: 0, female: 0, male: 0 }); // Clear summary

//       try {
//         const records = await fetchAllPages({
//           axiosInstance,
//           postfix: currentApiPostfix, // Use the dynamically determined postfix
//           filterKey: "ward_no",
//           filterValue: ward,
//         });

//         // Group by param
//         const group = {};
//         let totalFemale = 0;
//         let totalMale = 0;
//         let totalPopulation = 0;

//         records.forEach((rec) => {
//           let val = rec[param];
//           if (val === null || val === undefined || val === "") val = "अन्य";
//           group[val] = (group[val] || 0) + 1;

//           // For household survey, calculate total population, male, female
//           if (currentApiPostfix === API_POSTFIX_HSURVEY) {
//             totalPopulation += parseInt(rec.total_population || 0);
//             totalFemale += parseInt(rec.total_female || 0);
//             totalMale += parseInt(rec.total_male || 0);
//           }
//           // For institutional survey, 'total_population' might mean something else
//           // or not be available. We can adjust this summary logic as needed.
//           // For now, summary will show total records as population for institutional.
//         });

//         const data = Object.entries(group).map(([label, value]) => ({
//           label,
//           value,
//         }));
//         setTableData(data);

//         // Update summary based on the current API postfix
//         if (currentApiPostfix === API_POSTFIX_HSURVEY) {
//           setSummary({
//             population: totalPopulation,
//             female: totalFemale,
//             male: totalMale,
//           });
//         } else {
//           // For institutional reports, population can be sum of records if no specific field
//           setSummary({ population: records.length, female: 0, male: 0 }); // Adjust if institutional data has similar fields
//         }

//         if (records.length === 0) {
//           setDataError("No data available for the selected ward and category.");
//         }
//       } catch (e) {
//         console.error("Error fetching or processing data:", e);
//         setDataError(
//           e.response?.data?.error ||
//             e.message ||
//             "Failed to load data due => an unexpected error."
//         );
//         setTableData([]); // Ensure tableData is empty on error
//         setSummary({ population: 0, female: 0, male: 0 }); // Clear summary on error
//       } finally {
//         setLoading(false);
//       }
//     }
//     autoSearch();
//   }, [param, ward, axiosInstance, authLoading, authError, currentApiPostfix]); // currentApiPostfix is now a dependency

//   // Chart data (derived from tableData)
//   const chartCategories = tableData.map((d) => d.label);
//   const chartValues = tableData.map((d) => d.value);

//   const pieOptions = {
//     chart: { type: "pie" },
//     title: { text: param },
//     series: [
//       {
//         name: "घर संख्या", // This might need to be dynamic too based on report type (e.g., "संस्था संख्या")
//         data: tableData.map((d) => ({ name: d.label, y: d.value })),
//       },
//     ],
//   };

//   const barOptions = {
//     chart: { type: "column" },
//     title: { text: param },
//     xAxis: { categories: chartCategories },
//     yAxis: { title: { text: "घर संख्या" } }, // This might need to be dynamic too
//     series: [
//       {
//         name: "घर संख्या", // This might need to be dynamic too
//         data: chartValues,
//       },
//     ],
//   };

//   // Handle ward selection from header
//   const handleWardSelect = (selectedWard) => {
//     setWard(selectedWard);
//   };

//   // Centralized Loading and Error States
//   if (authLoading) {
//     return (
//       <div className="w-full h-screen flex justify-center items-center bg-gray-50 dark:bg-gray-900 text-gray-800">
//         <div className="flex flex-col items-center justify-center text-center py-10">
//           <div className="w-10 h-10 border-4 border-gray-300 border-t-blue-500 rounded-full animate-spin mb-4"></div>
//           <p className="text-gray-800 dark:text-gray-200 text-sm sm:text-base">
//             प्रमाणीकरण हुँदैछ... {/* Nepali for "Authenticating..." */}
//           </p>
//         </div>
//       </div>
//     );
//   }

//   if (authError) {
//     return (
//       <div className="w-full h-screen flex justify-center items-center bg-gray-50 dark:bg-gray-900 text-red-600">
//         <div className="flex flex-col items-center justify-center text-center py-10 px-4">
//           <p className="text-red-600 text-lg font-semibold mb-2">
//             त्रुटि! {/* Nepali for "Error!" */}
//           </p>
//           <p className="text-gray-700 dark:text-gray-300 text-sm">
//             API प्रमाणीकरण असफल भयो: {authError}{" "}
//             {/* Nepali for "API authentication failed:" */}
//           </p>
//           <p className="text-gray-500 dark:text-gray-400 text-xs mt-2">
//             कृपया पृष्ठ ताजा गर्नुहोस् वा प्रशासकलाई सम्पर्क गर्नुहोस्।{" "}
//             {/* Nepali for "Please refresh the page or contact the administrator." */}
//           </p>
//         </div>
//       </div>
//     );
//   }

//   // Main layout if authenticated and no auth error
//   return (
//     <div className="flex h-screen overflow-hidden">
//       <ReportSidebar
//         sidebarOpen={sidebarOpen}
//         setSidebarOpen={setSidebarOpen}
//       />
//       <div className="relative flex flex-col flex-1 overflow-y-auto overflow-x-hidden">
//         <Header
//           sidebarOpen={sidebarOpen}
//           setSidebarOpen={setSidebarOpen}
//           onSelectWard={handleWardSelect}
//           currentWard={ward} // Pass current ward to Header for initial selection
//           wardOptions={WARD_OPTIONS} // Pass ward options to Header
//         />
//         <main className="flex-grow">
//           <div className="container mx-auto p-4">
//             {loading ? (
//               <div className="flex justify-center items-center h-64 bg-white rounded shadow-md">
//                 <div className="flex flex-col items-center">
//                   <div className="w-10 h-10 border-4 border-gray-300 border-t-blue-500 rounded-full animate-spin mb-4"></div>
//                   <p className="text-gray-800 text-sm sm:text-base">
//                     डाटा लोड हुँदैछ... {/* Nepali for "Data is loading..." */}
//                   </p>
//                 </div>
//               </div>
//             ) : dataError ? (
//               <div className="flex justify-center items-center h-64 bg-white rounded shadow-md">
//                 <div className="flex flex-col items-center text-red-600 text-center px-4">
//                   <p className="text-lg font-semibold mb-2">
//                     डाटा लोड गर्न असफल भयो।{" "}
//                     {/* Nepali for "Failed to load data." */}
//                   </p>
//                   <p className="text-gray-700 text-sm">
//                     {dataError} {/* Display specific data error message */}
//                   </p>
//                 </div>
//               </div>
//             ) : tableData.length === 0 && !loading && !dataError ? (
//               <div className="flex justify-center items-center h-64 bg-white rounded shadow-md">
//                 <p className="text-gray-700 text-lg">
//                   कुनै डाटा उपलब्ध छैन। {/* Nepali for "No data available." */}
//                 </p>
//               </div>
//             ) : (
//               <>
//                 {/* Summary Cards */}
//                 <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
//                   <SummaryCard
//                     icon="fas fa-users"
//                     value={summary.population}
//                     label={
//                       currentApiPostfix === API_POSTFIX_HSURVEY
//                         ? "जम्मा घरधुरी"
//                         : "जम्मा संस्था"
//                     }
//                   />
//                   {currentApiPostfix === API_POSTFIX_HSURVEY && ( // Only show female/male for household
//                     <>
//                       <SummaryCard
//                         icon="fas fa-user-alt"
//                         value={summary.female}
//                         label="महिला"
//                       />
//                       <SummaryCard
//                         icon="fas fa-user-alt"
//                         value={summary.male}
//                         label="पुरुष"
//                       />
//                     </>
//                   )}
//                 </div>

//                 {/* Charts */}
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
//                   <HighchartsChart
//                     options={pieOptions}
//                     title=""
//                     height="350px"
//                   />
//                   <HighchartsChart
//                     options={barOptions}
//                     title=""
//                     height="350px"
//                   />
//                 </div>

//                 {/* Table */}
//                 <div className="card bg-white rounded shadow">
//                   <div className="card-body p-4">
//                     <div className="overflow-x-auto">
//                       <table className="table table-bordered table-sm w-full border border-gray-300 text-sm hover:table-hover">
//                         <thead className="bg-blue-600">
//                           <tr>
//                             <th className="text-center text-white font-semibold py-2 px-3">
//                               {param}
//                             </th>
//                             <th className="text-center text-white font-semibold py-2 px-3">
//                               {currentApiPostfix === API_POSTFIX_HSURVEY
//                                 ? "घर संख्या"
//                                 : "संस्था संख्या"}
//                             </th>
//                           </tr>
//                         </thead>
//                         <tbody>
//                           {tableData.map((row, idx) => (
//                             <tr
//                               key={idx}
//                               className={
//                                 idx % 2 === 0
//                                   ? "bg-white hover:bg-blue-50"
//                                   : "bg-gray-50 hover:bg-blue-50"
//                               }
//                             >
//                               <td className="text-center align-middle py-1 px-2 border border-gray-200">
//                                 {row.label}
//                               </td>
//                               <td className="text-center align-middle py-1 px-2 font-medium border border-gray-200">
//                                 {row.value}
//                               </td>
//                             </tr>
//                           ))}
//                         </tbody>
//                         <tfoot className="bg-gray-200">
//                           <tr>
//                             <td className="text-center font-bold py-1 px-2 border border-gray-200">
//                               जम्मा
//                             </td>
//                             <td className="text-center font-bold py-1 px-2 border border-gray-200">
//                               {tableData.reduce((sum, r) => sum + r.value, 0)}
//                             </td>
//                           </tr>
//                         </tfoot>
//                       </table>
//                     </div>
//                   </div>
//                 </div>
//               </>
//             )}
//           </div>
//         </main>
//       </div>
//     </div>
//   );
// }

// function SummaryCard({ icon, value, label }) {
//   return (
//     <div className="bg-gray-100 dark:bg-gray-800 rounded-lg shadow p-4 flex items-center">
//       <div className="flex-shrink-0 mr-4">
//         <div className="w-16 h-16 flex items-center justify-center rounded-full bg-blue-100 dark:bg-blue-900">
//           {/* Ensure Font Awesome is correctly linked in your project for these icons */}
//           <i className={`${icon} text-3xl text-blue-600 dark:text-blue-400`} />
//         </div>
//       </div>
//       <div>
//         <div className="text-2xl font-bold text-gray-800 dark:text-gray-100">
//           {value}
//         </div>
//         <div className="text-gray-600 dark:text-gray-300">{label}</div>
//       </div>
//     </div>
//   );
// }
